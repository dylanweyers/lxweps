lwep = {}

lwep.npcmodel = "models/dog.mdl"

lwep.cmds = {
	["!permweps"] = true,
	["!lweps"] = true,
}

lwep.users = {
	["STEAM_0:1:64763283"] = true,
}

lwep.ranks = {
	["owner"] = true,
	["co-owner"] = true,
	["superadmin"] = true,
}